$(".shadows").hover(function () {
    $(this).addClass("shadowsover");
});